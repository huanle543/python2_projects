TPOT was developed in the [Computational Genetics Lab](http://epistasis.org) with funding from the [NIH](http://www.nih.gov) under grant R01 AI117694. We're incredibly grateful for their support during the development of this project.

The TPOT logo was designed by Todd Newmuis, who generously donated his time to the project.
