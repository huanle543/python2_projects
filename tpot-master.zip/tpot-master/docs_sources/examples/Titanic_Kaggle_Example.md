To see the TPOT applied the Titanic Kaggle dataset, see the Jupyter notebook [here](https://github.com/rhiever/tpot/blob/master/tutorials/Titanic_Kaggle.ipynb).
